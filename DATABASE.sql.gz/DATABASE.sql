-- phpMyAdmin SQL Dump
-- version 3.2.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 03, 2010 at 02:55 PM
-- Server version: 5.0.82
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `grad5app`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE IF NOT EXISTS `applicants` (
  `applicant_id` int(10) unsigned NOT NULL auto_increment COMMENT 'PS: required',
  `given_name` varchar(30) NOT NULL COMMENT 'PS: required',
  `middle_name` varchar(30) NOT NULL,
  `family_name` varchar(30) NOT NULL COMMENT 'PS: required',
  `suffix` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `login_email` varchar(100) NOT NULL,
  `login_email_confirmed` tinyint(1) NOT NULL default '0',
  `login_email_code` varchar(40) NOT NULL,
  `forgot_password_code` varchar(40) NOT NULL,
  `password` varchar(155) NOT NULL,
  `alternate_name` varchar(55) NOT NULL,
  `mailing_addr1` varchar(55) NOT NULL,
  `mailing_addr2` varchar(55) NOT NULL,
  `mailing_city` varchar(55) NOT NULL,
  `mailing_state` varchar(55) NOT NULL,
  `mailing_postal` varchar(55) NOT NULL COMMENT 'PS: 5 char-pad with 0s',
  `primary_phone` varchar(30) NOT NULL COMMENT 'PS: 10 char xxxxxxxxxx',
  `secondary_phone` varchar(30) NOT NULL COMMENT 'PS: 10 char xxxxxxxxxx',
  `permanent_addr1` varchar(55) NOT NULL COMMENT 'PS: required',
  `permanent_addr2` varchar(55) NOT NULL,
  `permanent_city` varchar(30) NOT NULL COMMENT 'PS: required',
  `permanent_state` varchar(30) NOT NULL,
  `permanent_postal` varchar(5) NOT NULL,
  `date_of_birth` varchar(10) NOT NULL COMMENT 'PS: mm/dd/yyyy',
  `birth_city` varchar(30) NOT NULL,
  `birth_state` varchar(30) NOT NULL,
  `birth_country` char(3) NOT NULL,
  `gender` char(1) NOT NULL COMMENT 'PS: M/F',
  `us_citizen` tinyint(1) NOT NULL COMMENT 'PS: 1/2 (1=US)',
  `us_state` char(2) NOT NULL,
  `residency_status` varchar(30) NOT NULL,
  `green_card_link` varchar(128) NOT NULL,
  `country_of_citizenship` char(3) NOT NULL,
  `social_security_number` varchar(11) NOT NULL COMMENT 'PS: pad with 0s',
  `ethnicity_amind` varchar(10) NOT NULL,
  `ethnicity_asian` varchar(10) NOT NULL,
  `ethnicity_black` varchar(10) NOT NULL,
  `ethnicity_hispa` varchar(10) NOT NULL,
  `ethnicity_pacif` varchar(10) NOT NULL,
  `ethnicity_white` varchar(10) NOT NULL,
  `ethnicity_unspec` varchar(10) NOT NULL,
  `languages_repeatable` int(3) NOT NULL default '1',
  `previousschools_repeatable` int(3) NOT NULL default '1',
  `english_years_school` varchar(10) NOT NULL,
  `english_years_univ` varchar(10) NOT NULL,
  `english_years_private` varchar(10) NOT NULL,
  `international_repeatable` int(3) NOT NULL default '1',
  `present_occupation` varchar(55) NOT NULL,
  `appliedprograms_repeatable` int(3) NOT NULL default '1',
  `start_semester` varchar(10) NOT NULL COMMENT 'PS: required SPRING/FALL/SUMMER',
  `start_year` int(4) NOT NULL COMMENT 'PS: required yyyy',
  `academic_program` varchar(10) NOT NULL COMMENT 'PS: required',
  `academic_plan` varchar(10) NOT NULL COMMENT 'PS: required',
  `academic_major` varchar(30) NOT NULL,
  `academic_minor` varchar(30) NOT NULL,
  `student_type` varchar(5) NOT NULL COMMENT 'PS: IS/OS/INTNL/NEBHE',
  `academic_load` char(1) NOT NULL COMMENT 'PS: F/P (fulltime/parttime)',
  `desired_housing` varchar(10) NOT NULL COMMENT 'PS: On Campus/Off Campus',
  `undergrad_gpa` decimal(3,2) NOT NULL,
  `postbacc_gpa` decimal(3,2) NOT NULL,
  `preenroll_courses` text NOT NULL,
  `extracurricular_activities` text NOT NULL,
  `academic_honors` text NOT NULL,
  `employment_history` text NOT NULL,
  `dviolations_repeatable` int(3) NOT NULL default '1',
  `cviolations_repeatable` int(3) NOT NULL default '1',
  `resume_link` varchar(128) NOT NULL,
  `essay_link` varchar(128) NOT NULL,
  `gre_repeatable` int(3) NOT NULL default '1',
  `gmat_date` varchar(7) NOT NULL,
  `gmat_score` int(3) NOT NULL,
  `mat_date` varchar(7) NOT NULL,
  `mat_score` int(3) NOT NULL,
  `prev_um_grad_app_date` varchar(7) NOT NULL,
  `prev_um_grad_app_dept` varchar(30) NOT NULL,
  `prev_um_grad_degree` varchar(30) NOT NULL,
  `prev_um_grad_degree_date` varchar(7) NOT NULL,
  `prev_um_grad_withdraw_date` varchar(7) NOT NULL,
  `desire_assistantship_dept` varchar(30) NOT NULL,
  `desire_financial_aid` char(1) NOT NULL COMMENT 'PS: Y/Blank',
  `um_correspond_details` text NOT NULL,
  `extrareferences_repeatable` int(3) NOT NULL default '0',
  `reference1_first` varchar(30) NOT NULL,
  `reference1_last` varchar(30) NOT NULL,
  `reference1_email` varchar(30) NOT NULL,
  `reference1_relationship` varchar(10) NOT NULL,
  `reference1_phone` varchar(18) NOT NULL,
  `reference1_addr1` varchar(55) NOT NULL,
  `reference1_addr2` varchar(55) NOT NULL,
  `reference1_city` varchar(30) NOT NULL,
  `reference1_state` varchar(30) NOT NULL,
  `reference1_postal` varchar(30) NOT NULL,
  `reference1_country` varchar(3) NOT NULL,
  `reference2_first` varchar(32) NOT NULL,
  `reference2_last` varchar(32) NOT NULL,
  `reference2_email` varchar(64) NOT NULL,
  `reference2_relationship` varchar(10) NOT NULL,
  `reference2_phone` varchar(18) NOT NULL,
  `reference2_addr1` varchar(55) NOT NULL,
  `reference2_addr2` varchar(55) NOT NULL,
  `reference2_city` varchar(32) NOT NULL,
  `reference2_state` varchar(32) NOT NULL,
  `reference2_postal` varchar(10) NOT NULL,
  `reference2_country` varchar(3) NOT NULL,
  `reference3_first` varchar(32) NOT NULL,
  `reference3_last` varchar(32) NOT NULL,
  `reference3_email` varchar(64) NOT NULL,
  `reference3_relationship` varchar(10) NOT NULL,
  `reference3_phone` varchar(18) NOT NULL,
  `reference3_addr1` varchar(55) NOT NULL,
  `reference3_addr2` varchar(55) NOT NULL,
  `reference3_city` varchar(32) NOT NULL,
  `reference3_state` varchar(32) NOT NULL,
  `reference3_postal` varchar(10) NOT NULL,
  `reference3_country` varchar(3) NOT NULL,
  `application_start_date` date NOT NULL,
  `application_edit_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `application_submit_date` date NOT NULL COMMENT 'PS: mm/dd/yyyy',
  `application_signed_date` date NOT NULL,
  `application_fee_payment_status` char(1) NOT NULL COMMENT 'PS: Y/N',
  `application_fee_transaction_type` varchar(6) NOT NULL COMMENT 'PS: Online/blank',
  `application_fee_transaction_date` date NOT NULL COMMENT 'PS: mm/dd/yyyy',
  `application_fee_transaction_amount` decimal(5,2) NOT NULL COMMENT 'PS: xxx.xx',
  `application_fee_transaction_number` int(12) NOT NULL COMMENT 'PS: touchnet trans #',
  `has_been_pushed` tinyint(1) NOT NULL,
  `has_been_submitted` tinyint(1) NOT NULL,
  `gmat_verbal` int(2) NOT NULL,
  `gmat_quantitative` int(2) NOT NULL,
  `mailing_perm` tinyint(1) default NULL,
  `english_primary` tinyint(1) default NULL,
  `international` tinyint(1) default NULL,
  `disciplinary_violation` tinyint(1) default NULL,
  `gre_taken` tinyint(1) default NULL,
  `gmat_taken` tinyint(1) default NULL,
  `gmat_reported` tinyint(1) default NULL,
  `mat_taken` tinyint(1) default NULL,
  `mat_reported` tinyint(1) default NULL,
  `prev_um_app` tinyint(1) default NULL,
  `prev_um_grad_app` tinyint(1) default NULL,
  `prev_um_grad_withdraw` tinyint(1) default NULL,
  `desire_assistantship` tinyint(1) default NULL,
  `apply_nebhe` tinyint(1) default NULL,
  `um_correspond` tinyint(1) default NULL,
  `waive_view_rights` tinyint(1) default NULL,
  `reference1_online` tinyint(1) default NULL,
  `reference2_online` tinyint(1) default NULL,
  `reference3_online` tinyint(1) default NULL,
  `application_signed` tinyint(1) default NULL,
  `accept_terms` tinyint(1) default NULL,
  `criminal_violation` tinyint(1) default NULL,
  `transaction_id` varchar(128) default NULL,
  `gmat_analytical` decimal(2,1) NOT NULL,
  `mailing_country` char(3) default NULL,
  `permanent_country` char(3) default NULL,
  PRIMARY KEY  (`applicant_id`),
  UNIQUE KEY `transaction_id` (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `applicants`
--


-- --------------------------------------------------------

--
-- Table structure for table `application_cost`
--

CREATE TABLE IF NOT EXISTS `application_cost` (
  `first_program` int(2) NOT NULL,
  `additional_programs` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_cost`
--

INSERT INTO `application_cost` (`first_program`, `additional_programs`) VALUES
(65, 10);

-- --------------------------------------------------------

--
-- Table structure for table `appliedprograms`
--

CREATE TABLE IF NOT EXISTS `appliedprograms` (
  `applicant_id` int(32) NOT NULL,
  `appliedprograms_id` int(32) NOT NULL,
  `academic_program` varchar(10) NOT NULL,
  `academic_plan` varchar(10) NOT NULL,
  `academic_dept_code` varchar(3) NOT NULL,
  `academic_major` varchar(30) NOT NULL,
  `academic_minor` varchar(30) NOT NULL,
  `student_type` varchar(5) NOT NULL,
  `start_semester` varchar(6) NOT NULL,
  `start_year` varchar(4) NOT NULL,
  `attendance_load` char(1) NOT NULL,
  PRIMARY KEY  (`applicant_id`,`appliedprograms_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appliedprograms`
--


-- --------------------------------------------------------

--
-- Table structure for table `cviolations`
--

CREATE TABLE IF NOT EXISTS `cviolations` (
  `applicant_id` int(10) unsigned NOT NULL,
  `cviolations_id` int(10) unsigned NOT NULL auto_increment,
  `cviolation_type` varchar(12) NOT NULL,
  `cviolation_date` varchar(7) NOT NULL,
  `cviolation_details` text NOT NULL,
  PRIMARY KEY  (`applicant_id`,`cviolations_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cviolations`
--


-- --------------------------------------------------------

--
-- Table structure for table `dviolations`
--

CREATE TABLE IF NOT EXISTS `dviolations` (
  `applicant_id` int(10) unsigned NOT NULL,
  `dviolations_id` int(10) unsigned NOT NULL auto_increment,
  `dviolation_type` varchar(12) NOT NULL,
  `dviolation_date` varchar(7) NOT NULL,
  `dviolation_details` text NOT NULL,
  PRIMARY KEY  (`applicant_id`,`dviolations_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dviolations`
--


-- --------------------------------------------------------

--
-- Table structure for table `extrareferences`
--

CREATE TABLE IF NOT EXISTS `extrareferences` (
  `applicant_id` int(32) NOT NULL,
  `extrareferences_id` int(32) NOT NULL,
  `reference_first` varchar(32) NOT NULL,
  `reference_last` varchar(32) NOT NULL,
  `reference_email` varchar(128) NOT NULL,
  `reference_relationship` varchar(10) NOT NULL,
  `reference_phone` varchar(18) NOT NULL,
  `reference_addr1` varchar(55) NOT NULL,
  `reference_addr2` varchar(55) NOT NULL,
  `reference_city` varchar(30) NOT NULL,
  `reference_state` varchar(30) NOT NULL,
  `reference_postal` varchar(30) NOT NULL,
  `reference_country` varchar(3) NOT NULL,
  `reference_online` tinyint(1) default NULL,
  PRIMARY KEY  (`applicant_id`,`extrareferences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extrareferences`
--


-- --------------------------------------------------------

--
-- Table structure for table `gre`
--

CREATE TABLE IF NOT EXISTS `gre` (
  `applicant_id` int(32) NOT NULL,
  `gre_id` int(32) NOT NULL,
  `gre_date` varchar(7) NOT NULL,
  `gre_verbal` int(3) NOT NULL,
  `gre_quantitative` int(3) NOT NULL,
  `gre_analytical` decimal(2,1) NOT NULL,
  `gre_subject` varchar(32) NOT NULL,
  `gre_reported` tinyint(1) default NULL,
  `gre_score` int(3) NOT NULL,
  PRIMARY KEY  (`applicant_id`,`gre_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gre`
--


-- --------------------------------------------------------

--
-- Table structure for table `international`
--

CREATE TABLE IF NOT EXISTS `international` (
  `applicant_id` int(10) unsigned NOT NULL,
  `international_id` int(10) unsigned NOT NULL auto_increment,
  `toefl_date` varchar(7) NOT NULL,
  `toefl_score` int(3) NOT NULL,
  `us_career` tinyint(1) NOT NULL,
  `us_career_details` text NOT NULL,
  `further_studies_details` text NOT NULL,
  `home_career_details` text NOT NULL,
  `finance_details` text NOT NULL,
  `us_contacts` text NOT NULL,
  `us_emergency_contact_name` varchar(55) NOT NULL,
  `us_emergency_contact_addr1` varchar(55) NOT NULL,
  `us_emergency_contact_addr2` varchar(55) NOT NULL,
  `us_emergency_contact_city` varchar(30) NOT NULL,
  `us_emergency_contact_state` char(2) NOT NULL,
  `us_emergency_contact_zip` varchar(5) NOT NULL,
  `us_emergency_contact_phone` varchar(30) NOT NULL,
  `us_emergency_contact_relationship` varchar(30) NOT NULL,
  `home_emergency_contact_name` varchar(55) NOT NULL,
  `home_emergency_contact_addr1` varchar(55) NOT NULL,
  `home_emergency_contact_addr2` varchar(55) NOT NULL,
  `home_emergency_contact_city` varchar(30) NOT NULL,
  `home_emergency_contact_state` varchar(30) NOT NULL,
  `home_emergency_contact_postal` varchar(30) NOT NULL,
  `home_emergency_contact_country` varchar(3) NOT NULL,
  `home_emergency_contact_phone` varchar(30) NOT NULL,
  `home_emergency_contact_relationship` varchar(30) NOT NULL,
  `toefl_taken` tinyint(1) default NULL,
  `toefl_reported` tinyint(1) default NULL,
  `further_studies` tinyint(1) default NULL,
  `home_career` tinyint(1) default NULL,
  PRIMARY KEY  (`applicant_id`,`international_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `international`
--


-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `applicant_id` int(32) unsigned NOT NULL,
  `languages_id` int(32) unsigned NOT NULL,
  `language` varchar(30) NOT NULL,
  `writing_proficiency` varchar(4) NOT NULL,
  `reading_proficiency` varchar(4) NOT NULL,
  `speaking_proficiency` varchar(4) NOT NULL,
  PRIMARY KEY  (`applicant_id`,`languages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `languages`
--


-- --------------------------------------------------------

--
-- Table structure for table `previousschools`
--

CREATE TABLE IF NOT EXISTS `previousschools` (
  `applicant_id` int(10) unsigned NOT NULL,
  `previousschools_id` int(10) unsigned NOT NULL auto_increment,
  `previous_schools_name` varchar(55) NOT NULL,
  `previous_schools_city` varchar(30) NOT NULL,
  `previous_schools_state` varchar(30) NOT NULL,
  `previous_schools_country` varchar(3) NOT NULL,
  `previous_schools_code` varchar(4) NOT NULL,
  `previous_schools_from_date` varchar(7) NOT NULL,
  `previous_schools_to_date` varchar(7) NOT NULL,
  `previous_schools_major` varchar(30) NOT NULL,
  `previous_schools_degree_earned` varchar(30) NOT NULL,
  `previous_schools_degree_date` varchar(7) NOT NULL,
  PRIMARY KEY  (`applicant_id`,`previousschools_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Previous Schools Attended' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `previousschools`
--


-- --------------------------------------------------------

--
-- Table structure for table `progress`
--

CREATE TABLE IF NOT EXISTS `progress` (
  `applicant_id` int(10) NOT NULL,
  `structure_id` int(3) NOT NULL,
  `status` enum('INCOMPLETE','IN PROGRESS','PENDING','COMPLETE') NOT NULL default 'INCOMPLETE',
  `notes` varchar(512) NOT NULL,
  PRIMARY KEY  (`applicant_id`,`structure_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `progress`
--

INSERT INTO `progress` (`applicant_id`, `structure_id`, `status`, `notes`) VALUES
(11, 1, 'INCOMPLETE', ''),
(11, 2, 'INCOMPLETE', ''),
(11, 3, 'INCOMPLETE', ''),
(11, 4, 'INCOMPLETE', ''),
(11, 5, 'INCOMPLETE', ''),
(11, 6, 'INCOMPLETE', '');

-- --------------------------------------------------------

--
-- Table structure for table `structure`
--

CREATE TABLE IF NOT EXISTS `structure` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  `path` varchar(128) NOT NULL,
  `include` tinyint(1) NOT NULL,
  `order` int(3) unsigned default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `order` (`order`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `structure`
--

INSERT INTO `structure` (`id`, `name`, `path`, `include`, `order`) VALUES
(1, 'Application', '/', 1, 0),
(2, 'Personal Information', 'templates/personal.php', 1, 1),
(3, 'International', 'templates/international.php', 1, 2),
(4, 'Educational History', 'templates/history.php', 1, 3),
(5, 'Educational Objectives', 'templates/objectives.php', 1, 4),
(6, 'Letters of Recommendation', 'templates/recommendations.php', 1, 5),
(7, 'Additional Programs', 'templates/additional.php', 0, 6);

-- --------------------------------------------------------

--
-- Table structure for table `um_academic`
--

CREATE TABLE IF NOT EXISTS `um_academic` (
  `academic_index` int(8) NOT NULL auto_increment,
  `academic_program` varchar(10) NOT NULL,
  `academic_plan` varchar(10) NOT NULL,
  `academic_dept_code` varchar(3) NOT NULL,
  `academic_dept` varchar(64) NOT NULL,
  `academic_dept_heading` varchar(64) NOT NULL,
  `academic_degree` varchar(10) NOT NULL,
  `academic_degree_heading` varchar(4) NOT NULL,
  `description_app` varchar(30) NOT NULL,
  `description_list` varchar(30) NOT NULL,
  `nebhe_ct` varchar(1) NOT NULL,
  `nebhe_ma` varchar(1) NOT NULL,
  `nebhe_nh` varchar(1) NOT NULL,
  `nebhe_ri` varchar(1) NOT NULL,
  `nebhe_vt` varchar(1) NOT NULL,
  PRIMARY KEY  (`academic_index`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=132 ;

--
-- Dumping data for table `um_academic`
--

INSERT INTO `um_academic` (`academic_index`, `academic_program`, `academic_plan`, `academic_dept_code`, `academic_dept`, `academic_dept_heading`, `academic_degree`, `academic_degree_heading`, `description_app`, `description_list`, `nebhe_ct`, `nebhe_ma`, `nebhe_nh`, `nebhe_ri`, `nebhe_vt`) VALUES
(1, 'KPEME', 'KPE-MED', 'KPE', 'Kinesiology & Phys Edu', 'Kinesiology & Physical Education', 'MED', 'MEd', 'Kinesiology & Phys Edu-MED', 'Kinesiology & Phys Edu-MED', '', '', '', '', 'X'),
(2, 'ISYS', 'ISY-MS', 'ISY', 'Information Systems', 'Information Systems', 'MS', 'MS', 'Information Systems-MS', 'Information Systems-MS', 'X', 'X', 'X', 'X', 'X'),
(3, 'INTD', 'INT-PHD', 'INT', 'Interdisciplinary', 'Interdisciplinary', 'PHD', 'PhD', 'Interdisciplinary-PHD', 'Interdisciplinary-PHD', '', '', '', '', ''),
(4, 'IMMFA', 'IMD-MFA', 'IMD', 'Intermedia', 'Intermedia', 'MFA', 'MFA', 'Intermedia-MFA', 'Intermedia-MFA', 'X', 'X', 'X', 'X', 'X'),
(5, 'HUDS', 'HUD-MS', 'HUD', 'Human Development', 'Human Development', 'MS', 'MS', 'Human Development-MS', 'Human Development-MS', '', 'X', '', '', 'X'),
(6, 'HTYD', 'HTY-PHD', 'HTY', 'History', 'History', 'PHD', 'PhD', 'History-PHD', 'History-PHD', '', '', 'X', 'X', 'X'),
(7, 'HTYA', 'HTY-MA', 'HTY', 'History', 'History', 'MA', 'MA', 'History-MA', 'History-MA', '', '', '', '', ''),
(8, 'HELED', 'HEL-EDD', 'HEL', 'Higher Ed Leadership', 'Higher Education Leadership', 'EDD', 'EdD', 'Higher Ed Leadership-EDD', 'Higher Ed Leadership-EDD', 'X', 'X', 'X', 'X', ''),
(9, 'HEDME', 'HED-MED', 'HED', 'Higher Education', 'Higher Education', 'MED', 'MEd', 'Higher Education-MED', 'Higher Education-MED', '', '', '', '', ''),
(11, 'HEDCS', 'HED-CAS', 'HED', 'Higher Education', 'Higher Education', 'CAS', 'CAS', 'Higher Education-CAS', 'Higher Education-CAS', '', '', '', '', ''),
(12, 'HCLS', 'HCL-MS', 'HCL', 'Horticulture', 'Horticulture', 'MS', 'MS', 'Horticulture-MS', 'Horticulture-MS', '', '', '', '', ''),
(15, 'GISCG', 'GIS-CGS', 'GIS', 'Geographic Info Systems', 'Geographic Information Systems', 'CGS', 'Cert', 'Geographic Info Systems-CGS', 'Geographic Info Systems-CGS', '', '', '', '', ''),
(16, 'FTYMF', 'FTY-MFOR', 'FTY', 'Forestry', 'Forestry', 'MFOR', 'MFOR', 'Forestry-MFOR', 'Forestry-MFOR', '', '', '', '', ''),
(17, 'FSNS', 'FSN-MS', 'FSN', 'Food Sci & Human Nutr', 'Food and Nutrition Science', 'MS', 'MS', 'Food Sci & Human Nutr-MS', 'Food Sci & Human Nutr-MS', '', '', 'X', '', ''),
(18, 'FSCGS', 'FSN-CGS', 'FSN', 'Food Science Nutrition', 'Food and Nutrition Science', 'CGS', 'Cert', 'Food Science Nutrition-CGS', 'Food Science Nutrition-CGS', '', '', '', '', ''),
(19, 'FREAT', 'FRE-MAT', 'FRE', 'French', 'French', 'MAT', 'MAT', 'French-MAT', 'French-MAT', '', '', 'X', 'X', ''),
(20, 'FREA', 'FRE-MA', 'FRE', 'French', 'French', 'MA', 'MA', 'French-MA', 'French-MA', '', '', 'X', 'X', ''),
(21, 'FORS', 'FOR-MS', 'FOR', 'Forest Resources', 'Forest Resources', 'MS', 'MS', 'Forest Resources-MS', 'Forest Resources-MS', 'X', '', '', 'X', ''),
(22, 'FORD', 'FOR-PHD', 'FOR', 'Forest Resources', 'Forest Resources', 'PHD', 'PhD', 'Forest Resources-PHD', 'Forest Resources-PHD', 'X', '', 'X', 'X', 'X'),
(23, 'FNSD', 'FNS-PHD', 'FNS', 'Food & Nutrition Sci', 'Food and Nutrition Science', 'PHD', 'PhD', 'Food & Nutrition Sci-PHD', 'Food & Nutrition Sci-PHD', '', 'X', 'X', '', ''),
(24, 'FIEA', 'FIE-MA', 'FIE', 'Financial Economics', 'Financial Economics', 'MA', 'MA', 'Financial Economics-MA', 'Financial Economics-MA', 'X', 'X', 'X', 'X', 'X'),
(25, 'ESSME', 'ESS-MED', 'ESS', 'Social Studies Education', 'Social Studies Education', 'MED', 'MEd', 'Social Studies Education-MED', 'Social Studies Education-MED', '', '', '', '', ''),
(26, 'ESSCS', 'ESS-CAS', 'ESS', 'Social Studies Education', 'Social Studies Education', 'CAS', 'CAS', 'Social Studies Education-CAS', 'Social Studies Education-CAS', '', '', '', '', ''),
(27, 'ESCME', 'ESC-MED', 'ESC', 'Science Education', 'Science Education', 'MED', 'MEd', 'Science Education-MED', 'Science Education-MED', '', '', '', '', ''),
(28, 'ESCCS', 'ESC-CAS', 'ESC', 'Science Education', 'Science Education', 'CAS', 'CAS', 'Science Education-CAS', 'Science Education-CAS', '', '', 'X', 'X', 'X'),
(29, 'ERSS', 'ERS-MS', 'ERS', 'Earth Sciences', 'Earth Sciences', 'MS', 'MS', 'Earth Sciences-MS', 'Earth Sciences-MS', '', '', '', '', ''),
(30, 'ERSD', 'ERS-PHD', 'ERS', 'Earth Sciences', 'Earth Sciences', 'PHD', 'PhD', 'Earth Sciences-PHD', 'Earth Sciences-PHD', '', '', '', 'X', 'X'),
(31, 'EPSME', 'EPS-ME', 'EPS', 'Engineering Physics', 'Engineering Physics', 'ME', 'ME', 'Engineering Physics-ME', 'Engineering Physics-ME', '', '', '', '', ''),
(32, 'ENTS', 'ENT-MS', 'ENT', 'Entomology', 'Entomology', 'MS', 'MS', 'Entomology-MS', 'Entomology-MS', '', '', 'X', '', ''),
(33, 'ENGA', 'ENG-MA', 'ENG', 'English', 'English', 'MA', 'MA', 'English-MA', 'English-MA', '', '', '', '', ''),
(34, 'ELES', 'ELE-MS', 'ELE', 'Electrical Engineering', 'Electrical and Computer Engineering', 'MS', 'MS', 'Electrical Engineering-MS', 'Electrical Engineering-MS', '', '', '', '', ''),
(35, 'ELED', 'ELE-PHD', 'ELE', 'Elect & Comp Egr', 'Electrical and Computer Engineering', 'PHD', 'PhD', 'Elect & Comp Egr-PHD', 'Elect & Comp Egr PHD', '', '', '', '', ''),
(36, 'EESS', 'EES-MS', 'EES', 'Ecology/Environmental Sci', 'Ecology and Environmental Science', 'MS', 'MS', 'Ecology/Environmental Sci-MS', 'Ecology/Environmental Sci-MS', '', '', '', '', 'X'),
(37, 'EESD', 'EES-PHD', 'EES', 'Ecology/Environmental Sci', 'Ecology and Environmental Science', 'PHD', 'PhD', 'Ecology/Environmental Sci-PHD', 'Ecology/Environmental Sci-PHD', 'X', '', '', '', 'X'),
(38, 'EDXME', 'EDX-MED', 'EDX', 'Individualized in Educ', 'Individualized in Education', 'MED', 'MEd', 'Individualized in Educ-MED', 'Individualized in Educ-MED', '', '', '', '', ''),
(40, 'EDXCS', 'EDX-CAS', 'EDX', 'Individualized in Educ', 'Individualized in Education', 'CAS', '', 'Individualized in Educ-CAS', 'Individualized in Educ-CAS', '', '', '', '', ''),
(41, 'EDTME', 'EDT-MED', 'EDT', 'Instructional Technology', 'Instructional Technology', 'MED', 'MEd', 'Instructional Technology-MED', 'Instructional Technology-MED', '', '', 'X', 'X', 'X'),
(42, 'EDSAT', 'EDS-MAT', 'EDS', 'Secondary Education', 'Secondary Education', 'MAT', 'MAT', 'Secondary Education-MAT', 'Secondary Education-MAT', '', '', '', '', ''),
(43, 'EDLME', 'EDL-MED', 'EDL', 'Educational Leadership', 'Educational Leadership', 'MED', 'MEd', 'Educational Leadership-MED', 'Educational Leadership-MED', '', '', '', '', ''),
(44, 'EDLED', 'EDL-EDD', 'EDL', 'Educational Leadership', 'Educational Leadership', 'EDD', 'EdD', 'Educational Leadership-EDD', 'Educational Leadership-EDD', '', '', '', 'X', ''),
(45, 'EDLCS', 'EDL-CAS', 'EDL', 'Educational Leadership', 'Educational Leadership', 'CAS', 'CAS', 'Educational Leadership-CAS', 'Educational Leadership-CAS', '', '', 'X', 'X', ''),
(46, 'EDEAT', 'EDEMAT', 'EDE', 'Elementary Education', 'Elementary Education', 'EDEMAT', 'MAT', 'Elementary Education-EDEMAT', 'Elementary Education-MAT', '', '', '', '', ''),
(47, 'EDCME', 'EDC-MED', 'EDC', 'Elementary Education', 'Elementary Education', 'MED', 'MEd', 'Elementary Education-MED', 'Elementary Education-MED', '', '', '', '', ''),
(48, 'EDCCS', 'EDC-CAS', 'EDC', 'Elementary Education', 'Elementary Education', 'CAS', 'CAS', 'Elementary Education-CAS', 'Elementary Education-CAS', '', '', 'X', 'X', ''),
(49, 'EDAME', 'EDA-MED', 'EDA', 'Secondary Education', 'Secondary Education', 'MED', 'MEd', 'Secondary Education-MED', 'Secondary Education-MED', '', '', '', '', ''),
(50, 'EDACS', 'EDA-CAS', 'EDA', 'Secondary Education', 'Secondary Education', 'CAS', 'CAS', 'Secondary Education-CAS', 'Secondary Education-CAS', '', '', 'X', 'X', ''),
(51, 'ECOA', 'ECO-MA', 'ECO', 'Economics', 'Economics', 'MA', 'MA', 'Economics-MA', 'Economics-MA', '', '', '', 'X', 'X'),
(52, 'CSDA', 'CSD-MA', 'CSD', 'Comm Sciences & Disorders', 'Communication Sciences and Disorders', 'MA', 'MA', 'Comm Sciences & Disorders-MA', 'Comm Sciences & Disorders-MA', '', '', '', '', ''),
(53, 'COSS', 'COS-MS', 'COS', 'Computer Science', 'Computer Science', 'MS', 'MS', 'Computer Science-MS', 'Computer Science-MS', '', '', '', '', ''),
(54, 'COSD', 'COS-PHD', 'COS', 'Computer Science', 'Computer Science', 'PHD', 'PhD', 'Computer Science-PHD', 'Computer Science-PHD', '', '', '', '', ''),
(55, 'COMA', 'COM-MA', 'COM', 'Communication', 'Communication', 'MA', 'MA', 'Communication-MA', 'Communication-MA', '', '', 'X', '', 'X'),
(56, 'CIES', 'CIE-MS', 'CIE', 'Civil Engineering', 'Civil Engineering', 'MS', 'MS', 'Civil Engineering-MS', 'Civil Engineering-MS', '', '', '', '', ''),
(57, 'CIED', 'CIE-PHD', 'CIE', 'Civil Engineering', 'Civil Engineering', 'PHD', 'PhD', 'Civil Engineering-PHD', 'Civil Engineering-PHD', '', '', '', '', ''),
(58, 'CHYS', 'CHY-MS', 'CHY', 'Chemistry', 'Chemistry', 'MS', 'MS', 'Chemistry-MS', 'Chemistry-MS', '', '', '', '', ''),
(59, 'CHYD', 'CHY-PHD', 'CHY', 'Chemistry', 'Chemistry', 'PHD', 'PhD', 'Chemistry-PHD', 'Chemistry-PHD', '', '', '', '', ''),
(60, 'CHES', 'CHE-MS', 'CHE', 'Chemical Engineering', 'Chemical Engineering', 'MS', 'MS', 'Chemical Engineering-MS', 'Chemical Engineering-MS', '', '', '', '', 'X'),
(61, 'CHED', 'CHE-PHD', 'CHE', 'Chemical Engineering', 'Chemical Engineering', 'PHD', 'PhD', 'Chemical Engineering-PHD', 'Chemical Engineering-PHD', '', '', '', '', 'X'),
(62, 'CENS', 'CEN-MS', 'CEN', 'Computer Engineering', 'Computer Engineering', 'MS', 'MS', 'Computer Engineering-MS', 'Computer Engineering-MS', '', '', '', '', ''),
(63, 'CECME', 'CEC-MED', 'CEC', 'Counselor Education', 'Counselor Education', 'MED', 'MEd', 'Counselor Education-MED', 'Counselor Education-MED', '', '', '', '', ''),
(65, 'CECCS', 'CEC-CAS', 'CEC', 'Counselor Education', 'Counselor Education', 'CAS', 'CAS', 'Counselor Education-CAS', 'Counselor Education-CAS', '', '', '', '', ''),
(66, 'BUAMB', 'BUA-MBA', 'BUA', 'Business Admin', 'Business Administration', 'MBA', 'MBA', 'Business Admin-MBA', 'Business Admin-MBA', '', '', '', '', ''),
(67, 'BTPS', 'BTP-MS', 'BTP', 'Botany and Plant Pathology', 'Botany and Plant Pathology', 'MS', 'MS', 'Botany & Plant Pathology-MS', 'Botany & Plant Pathology-MS', 'X', '', '', '', ''),
(68, 'BSCD', 'BSC-PHD', 'BSC', 'Biological Science', 'Biological Science', 'PHD', 'PhD', 'Biological Science-PHD', 'Biological Science-PHD', '', '', '', '', ''),
(69, 'BMSD', 'BMS-PHD', 'BMS', 'Biomedical Sciences', 'Biomedical Sciences', 'PHD', 'PhD', 'Biomedical Sciences-PHD', 'Biomedical Sciences-PHD', '', '', '', '', ''),
(70, 'BMOD', 'BMO-PHD', 'BMO', 'Biochem/Molecular Biology', 'Biochemistry and Molecular Biology', 'PHD', 'PhD', 'Biochem/Molecular Biology-PHD', 'Biochem/Molecular Biology-PHD', '', '', '', '', ''),
(71, 'BLES', 'BLE-MS', 'BLE', 'Biological Engineering', 'Biological Engineering', 'MS', 'MS', 'Biological Engineering-MS', 'Biological Engineering-MS', 'X', 'X', 'X', 'X', 'X'),
(72, 'BLEME', 'BLE-ME', 'BLE', 'Biological Engineering', 'Biological Engineering', 'ME', 'ME', 'Biological Engineering-ME', 'Biological Engineering-ME', 'X', 'X', 'X', 'X', 'X'),
(73, 'BCHS', 'BCH-MS', 'BCH', 'Biochemistry', 'Biochemistry', 'MS', 'MS', 'Biochemistry-MS', 'Biochemistry-MS', '', '', '', '', ''),
(74, 'BCHPS', 'BCH-MPS', 'BCH', 'Biochemistry', 'Biochemistry', 'MPS', 'MPS', 'Biochemistry-MPS', 'Biochemistry-MPS', '', '', '', '', ''),
(75, 'ANSS', 'ANS-MS', 'ANS', 'Animal Sciences', 'Animal Sciences', 'MS', 'MS', 'Animal Sciences-MS', 'Animal Sciences-MS', '', '', '', '', ''),
(76, 'ANSPS', 'ANS-MPS', 'ANS', 'Animal Sciences', 'Animal Sciences', 'MPS', 'MPS', 'Animal Sciences-MPS', 'Animal Sciences-MPS', '', '', '', '', ''),
(77, 'AECGS', 'AEWC-CGS', 'AEW', 'Advanced Egr Wood Comp', 'Advanced Engineering Wood Composite', 'CGS', 'Cert', 'Advanced Egr Wood Comp-CGS', 'Advanced Egr Wood Comp CGS', '', '', '', '', ''),
(79, 'KPES', 'KPE-MS', 'KPE', 'Kinesiology & Phys Edu', 'Kinesiology & Physical Education', 'MS', 'MS', 'Kinesiology & Phys Edu-MS', 'Kinesiology & Phys Edu-MS', '', '', '', '', 'X'),
(80, 'LEDCS', 'LED-CAS', 'LED', 'Literacy Education', 'Literacy Education', 'CAS', 'CAS', 'Literacy Education-CAS', 'Literacy Education-CAS', '', '', 'X', 'X', ''),
(81, 'LEDED', 'LED-EDD', 'LED', 'Literacy Education', 'Literacy Education', 'EDD', 'EdD', 'Literacy Education-EDD', 'Literacy Education-EDD', 'X', '', '', 'X', 'X'),
(82, 'LEDME', 'LED-MED', 'LED', 'Literacy Education', 'Literacy Education', 'MED', 'MEd', 'Literacy Education-MED', 'Literacy Education-MED', '', '', '', '', ''),
(83, 'MABD', 'MAB-PHD', 'MAB', 'Marine Biology', 'Marine Biology', 'PHD', 'PhD', 'Marine Biology-PHD', 'Marine Biology-PHD', '', '', '', '', 'X'),
(84, 'MABS', 'MAB-MS', 'MAB', 'Marine Biology', 'Marine Biology', 'MS', 'MS', 'Marine Biology-MS', 'Marine Biology-MS', '', '', '', '', 'X'),
(85, 'MAPS', 'MAP-MS', 'MAP', 'Marine Policy', 'Marine Policy', 'MS', 'MS', 'Marine Policy-MS', 'Marine Policy-MS', 'X', 'X', 'X', '', 'X'),
(86, 'MATA', 'MAT-MA', 'MAT', 'Mathematics', 'Mathematics', 'MA', 'MA', 'Mathematics-MA', 'Mathematics-MA', '', '', '', '', ''),
(87, 'MBRD', 'MBR-PHD', 'MBR', 'Marine Bio', 'Marine Bio-Resources', 'PHD', 'PhD', 'Marine Bio-PHD', 'Marine Bio-Resources-PHD', '', '', '', '', 'X'),
(88, 'MBRS', 'MBR-MS', 'MBR', 'Marine Bio', 'Marine Bio-Resources', 'MS', 'MS', 'Marine Bio-MS', 'Marine Bio-Resources-MS', '', '', '', '', 'X'),
(89, 'MCBD', 'MCB-PHD', 'MCB', 'Microbiology', 'Microbiology', 'PHD', 'PhD', 'Microbiology-PHD', 'Microbiology-PHD', '', '', '', '', ''),
(90, 'MCBPS', 'MCB-MPS', 'MCB', 'Microbiology', 'Microbiology', 'MPS', 'MPS', 'Microbiology-MPS', 'Microbiology-MPS', '', '', '', '', ''),
(91, 'MCBS', 'MCB-MS', 'MCB', 'Microbiology', 'Microbiology', 'MS', 'MS', 'Microbiology-MS', 'Microbiology-MS', '', '', '', '', ''),
(92, 'MEED', 'MEE-PHD', 'MEE', 'Mechanical Engineering', 'Mechanical Engineering', 'PHD', 'PhD', 'Mechanical Engineering-PHD', 'Mechanical Engineering-PHD', '', '', '', '', ''),
(93, 'MEES', 'MEE-MS', 'MEE', 'Mechanical Engineering', 'Mechanical Engineering', 'MS', 'MS', 'Mechanical Engineering-MS', 'Mechanical Engineering-MS', '', '', '', '', ''),
(94, 'MLSA', 'MLS-MA', 'MLS', 'Liberal Studies', 'Liberal Studies', 'MA', 'MA', 'Liberal Studies-MA', 'Liberal Studies-MA', 'X', 'X', '', '', 'X'),
(96, 'MUIMM', 'MUI-MM', 'MUI', 'Music Education', 'Music Education', 'MM', 'MM', 'Music Education-MM', 'Music Education-MMUS', '', '', '', '', 'X'),
(97, 'MUPMM', 'MUP-MM', 'MUP', 'Music Performance', 'Music Performance', 'MM', 'MM', 'Music Performance-MM', 'Music Performance-MMUS', '', '', '', '', 'X'),
(100, 'NURCS', 'NUR-CAS', 'NUR', 'Nursing', 'Nursing', 'CAS', 'CAS', 'Nursing-CAS', 'Nursing-CAS', 'X', '', 'X', 'X', 'X'),
(101, 'NURS', 'NUR-MS', 'NUR', 'Nursing', 'Nursing', 'MS', 'MS', 'Nursing-MS', 'Nursing-MS', '', '', '', '', ''),
(102, 'OCED', 'OCE-PHD', 'OCE', 'Oceanography', 'Oceanography', 'PHD', 'PhD', 'Oceanography-PHD', 'Oceanography-PHD', '', '', '', '', 'X'),
(103, 'OCES', 'OCE-MS', 'OCE', 'Oceanography', 'Oceanography', 'MS', 'MS', 'Oceanography-MS', 'Oceanography-MS', '', '', '', '', 'X'),
(105, 'PHYD', 'PHY-PHD', 'PHY', 'Physics', 'Physics', 'PHD', 'PhD', 'Physics-PHD', 'Physics-PHD', '', '', '', '', 'X'),
(106, 'PHYS', 'PHY-MS', 'PHY', 'Physics', 'Physics', 'MS', 'MS', 'Physics-MS', 'Physics-MS', '', '', '', '', ''),
(107, 'PLSD', 'PLS-PHD', 'PLS', 'Plant Science', 'Plant Science', 'PHD', 'PhD', 'Plant Science-PHD', 'Plant Science-PHD', '', '', '', '', ''),
(108, 'PSES', 'PSE-MS', 'PSE', 'Plant Soil Envir Sci', 'Plant Soil & Environmental Science', 'MS', 'MS', 'Plant Soil Envir Sci-MS', 'Plant Soil Envir Sci-MS', 'X', '', '', '', ''),
(109, 'PSYA', 'PSY-MA', 'PSY', 'Psychology', 'Psychology', 'MA', 'MA', 'Psychology-MA', 'Psychology-MA', '', '', 'X', '', ''),
(110, 'PSYD', 'PSY-PHD', 'PSY', 'Psychology', 'Psychology', 'PHD', 'PhD', 'Psychology-PHD', 'Psychology-PHD', '', '', '', '', ''),
(111, 'PYCD', 'PYC-PHD', 'PYC', 'Clinical Psychology', 'Clinical Psychology', 'PHD', 'PhD', 'Clinical Psychology-PHD', 'Clinical Psychology-PHD', '', '', 'X', '', ''),
(112, 'QCSS', 'QCS-MS', 'QCS', 'Quaternary & Climate Std', 'Quaternary & Climate Studies', 'MS', 'MS', 'Quaternary & Climate Std-MS', 'Quaternary & Climate Std-MS', 'X', 'X', 'X', 'X', 'X'),
(113, 'REPS', 'REP-MS', 'REP', 'Resource Economics & Policy', 'Resource Economics & Policy', 'MS', 'MS', 'Resource Economics & Policy-MS', 'Resource Economics & Policy-MS', '', '', '', '', ''),
(114, 'SEDCS', 'SED-CAS', 'SED', 'Special Education', 'Special Education', 'CAS', 'CAS', 'Special Education-CAS', 'Special Education-CAS', '', '', '', '', ''),
(115, 'SEDME', 'SED-MED', 'SED', 'Special Education', 'Special Education', 'MED', 'MEd', 'Special Education-MED', 'Special Education-MED', '', '', '', '', ''),
(116, 'SISD', 'SIS-PHD', 'SIS', 'Spatial Inf Sci Engineer', 'Spatial Information Science & Engineering', 'PHD', 'PhD', 'Spatial Inf Sci Engineer-PHD', 'Spatial Inf Sci Engineer-PHD', 'X', 'X', 'X', 'X', 'X'),
(117, 'SISS', 'SIS-MS', 'SIS', 'Spatial Inf Sci Engineer', 'Spatial Information Science & Engineering', 'MS', 'MS', 'Spatial Inf Sci Engineer-MS', 'Spatial Inf Sci Engineer-MS', 'X', 'X', 'X', 'X', 'X'),
(118, 'SMTST', 'SMT-MST', 'SMT', 'Teaching', 'MS in Teaching Science & Mathematics', 'MST', 'MST', 'Teaching-MST', 'Teaching-MST', '', '', '', '', 'X'),
(119, 'SWKSW', 'SWK-MSW', 'SWK', 'Social Work', 'Social Work', 'MSW', 'MSW', 'Social Work-MSW', 'Social Work-MSW', '', '', '', '', ''),
(120, 'WLCWC', 'WLC-MWC', 'WLC', 'Wildlife Conservation', 'Wildlife Conservation', 'MWC', 'MWC', 'Wildlife Conservation-MWC', 'Wildlife Conservation-MWC', '', '', '', '', ''),
(121, 'WLED', 'WLE-PHD', 'WLE', 'Wildlife Ecology', 'Wildlife Ecology', 'PHD', 'PhD', 'Wildlife Ecology-PHD', 'Wildlife Ecology-PHD', 'X', '', 'X', 'X', 'X'),
(122, 'WLES', 'WLE-MS', 'WLE', 'Wildlife Ecology', 'Wildlife Ecology', 'MS', 'MS', 'Wildlife Ecology-MS', 'Wildlife Ecology-MS', '', '', '', '', ''),
(123, 'ZOLD', 'ZOL-PHD', 'ZOL', 'Zoology', 'Zoology', 'PHD', 'PhD', 'Zoology-PHD', 'Zoology-PHD', '', '', '', '', ''),
(124, 'ZOLS', 'ZOL-MS', 'ZOL', 'Zoology', 'Zoology', 'MS', 'MS', 'Zoology-MS', 'Zoology-MS', '', '', '', '', ''),
(125, 'HELD', 'HEL-PHD', 'HEL', 'Higher Ed Leadership', 'Higher Education Leadership', 'PHD', 'PhD', 'Higher Ed Leadership-PHD', 'Higher Ed Leadership-PHD', '', '', '', '', ''),
(126, 'EDLD', 'EDL-PHD', 'EDL', 'Educational Leadership', 'Educational Leadership', 'PHD', 'PhD', 'Educational Leadership-PHD', 'Educational Leadership-PHD', '', '', '', '', ''),
(127, 'LEDD', 'LED-PHD', 'LED', 'Literacy Education', 'Literacy Education', 'PHD', 'PhD', 'Literacy Education-PHD', 'Literacy Education-PHD', '', '', '', '', ''),
(129, 'GPLM', 'GLP-MA', 'GLP', 'Global Policy', 'Global Policy', 'MA', 'MA', 'Global Policy-MA', 'Global Policy-MA', '', '', '', '', ''),
(130, 'CAID', 'CAI-PHD', 'CAI', 'Curriculum and Instruction', 'Curriculum and Instruction', 'PHD', 'PhD', 'Curriculum and Instruction-PhD', 'Curriculum and Instruction-PhD', '', '', '', '', ''),
(131, 'ISCGS', 'ISY-CGS', 'ISY', 'Information Systems', 'Information Systems', 'CGS', 'CGS', 'Information Systems-CGS', 'Information Systems-CGS', '', '', '', '', '');
